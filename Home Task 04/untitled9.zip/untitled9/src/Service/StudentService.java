package Service;

import Model.User;

import java.util.List;

public interface StudentService<T extends User> {
    void add(T student);

    void remove(T student);

    void edit(T student);

    List<T> getAllStudents();
}
