import Model.Student;
import Service.StudentService;
import Service.impls.StudentServiceImpl;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        StudentService studentService = new StudentServiceImpl();
        studentService.add(new Student("Roman", 25, Arrays.asList("User"), 4.92f, 4));

        studentService.getAllStudents();
    }

}
