package Controller;

import Model.Student;
import Service.StudentService;
import Service.impls.StudentServiceImpl;
import java.util.List;

//Контроллер
public class StudentController {
    private StudentService studentService = new StudentServiceImpl();

    public void getStudentInfo(String name, int age, List<String> roles, float grade, int year) {
        studentService.add(new Student(name, age, roles, grade, year));
    }

}
