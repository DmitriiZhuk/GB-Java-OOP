package Repository;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import Model.Teacher;

public class TeacherRepository {
    // save method as before
    public void save(Teacher teacher) {
        try (FileWriter fileWriter = new FileWriter("teachers.txt")) {
            fileWriter.write(teacher.toString());
            fileWriter.flush();
        } catch (Exception exception) {
        }
    }

    public void remove(Teacher teacher) {
        try (BufferedReader reader = new BufferedReader(new FileReader("teachers.txt"))) {
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.contains(teacher.getName())) {
                    lines.add(line);
                }
            }
            try (FileWriter fileWriter = new FileWriter("teachers.txt")) {
                for (String l : lines) {
                    fileWriter.write(l);
                }
                fileWriter.flush();
            } catch (Exception exception) {
            }
        } catch (Exception exception) {
        }
    }

    public void edit(String name) {
        try (BufferedReader reader = new BufferedReader(new FileReader("teachers.txt"))) {
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(name)) {
                    // edit the line here
                } else {
                    lines.add(line);
                }
            }
            try (FileWriter fileWriter = new FileWriter("teachers.txt")) {
                for (String l : lines) {
                    fileWriter.write(l);
                }
                fileWriter.flush();
            } catch (Exception exception) {
            }
        } catch (Exception exception) {
        }
    }
}
