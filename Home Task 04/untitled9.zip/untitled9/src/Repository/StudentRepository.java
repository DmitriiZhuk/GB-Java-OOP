package Repository;

import Model.Student;

import java.io.*;

import java.util.*;

public class StudentRepository {
    public void save(Student student) {
        try (FileWriter fileWriter = new FileWriter("students.txt")) {
            fileWriter.write(student.toString());
            fileWriter.flush();

        } catch (Exception exception) {
        }
    }

    public void remove(Student student) {
        List<Student> students = readStudentsFromFile();

        students.remove(student);
        writeStudentsToFile(students);
    }

    public void edit(Student student) {
        List<Student> students = readStudentsFromFile();

        int index = students.indexOf(student);

        students.set(index, student);

        writeStudentsToFile(students);
    }

    public List<Student> getAllStudents() {
        List<Student> students = readStudentsFromFile();
        return students;
    }

    private List<Student> readStudentsFromFile() {
        List<Student> students = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("students.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                int age = Integer.parseInt(parts[1]);
                List<String> roles = Arrays.asList(parts[2].split(" "));
                float grade = Float.parseFloat(parts[3]);
                int year = Integer.parseInt(parts[4]);
                Student student = new Student(name, age, roles, grade, year);
                students.add(student);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return students;
    }

    private void writeStudentsToFile(List<Student> students) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("students.txt"))) {
            for (Student student : students) {
                String line = student.getName() + "," + student.getGrade() + "," + student.getYear();
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
